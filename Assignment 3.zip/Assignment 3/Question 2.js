var age=12;

console.log("Age:",age);

if(age>=18)
{
    alert("Drive safe");
}
else
{
    alert("Not legal age to drive");
}